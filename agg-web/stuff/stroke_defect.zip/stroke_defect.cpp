#include <math.h>
#include <stdio.h>
#include "agg_basics.h"
#include "agg_rendering_buffer.h"
#include "agg_rasterizer_scanline_aa.h"
#include "agg_conv_stroke.h"
#include "agg_conv_dash.h"
#include "agg_conv_curve.h"
#include "agg_conv_contour.h"
#include "agg_conv_smooth_poly1.h"
#include "agg_conv_marker.h"
#include "agg_arrowhead.h"
#include "agg_vcgen_markers_term.h"
#include "agg_scanline_p.h"
#include "agg_renderer_scanline.h"
#include "agg_pixfmt_rgb24.h"
#include "platform/agg_platform_support.h"
#include "ctrl/agg_slider_ctrl.h"
#include "../../interactive_polygon.h"


enum { flip_y = true };



class the_application : public agg::platform_support
{
    agg::slider_ctrl<agg::rgba8> m_width;
    agg::slider_ctrl<agg::rgba8> m_inner_lim;
    agg::interactive_polygon     m_poly;


public:
    the_application(agg::pix_format_e format, bool flip_y) :
        agg::platform_support(format, flip_y),
        m_width    (130 + 10.0, 10.0, 500.0 - 10.0, 10.0 + 7.0, !flip_y),
        m_inner_lim(130 + 10.0, 25.0, 500.0 - 10.0, 25.0 + 7.0, !flip_y),
        m_poly(7, 5.0)
    {
        add_ctrl(m_width);
        m_width.range(3.0, 40.0);
        m_width.value(20.0);
        m_width.label("Width=%1.2f");
        m_width.no_transform();

        add_ctrl(m_inner_lim);
        m_inner_lim.range(1.1, 20.0);
        m_inner_lim.value(1.1);
        m_inner_lim.label("Inner Miter Limit=%1.2f");
        m_inner_lim.no_transform();
    }

    virtual void on_init()
    {

/*
        //-----------------------------------------------------------
        // The simplest variant
        m_poly.xn(0) = 100;
        m_poly.yn(0) = 100;
        m_poly.xn(1) = 200;
        m_poly.yn(1) = 200;
        m_poly.xn(2) = 200+5;
        m_poly.yn(2) = 300;
        m_poly.xn(3) = 200+10;
        m_poly.yn(3) = 200;
        m_poly.xn(4) = 300;
        m_poly.yn(4) = 100;
        m_poly.xn(5) = 400;
        m_poly.yn(5) = 250;
        m_poly.xn(6) = 400;
        m_poly.yn(6) = 100;
*/





        //-----------------------------------------------------------
        // The curve variant
        m_poly.xn(0) = 100;
        m_poly.yn(0) = 100;
        m_poly.xn(1) = 100;
        m_poly.yn(1) = 250;
        m_poly.xn(2) = 250-10;
        m_poly.yn(2) = 250;
        m_poly.xn(3) = 250;
        m_poly.yn(3) = 100;
        m_poly.xn(4) = 250+10;
        m_poly.yn(4) = 250;
        m_poly.xn(5) = 400;
        m_poly.yn(5) = 250;
        m_poly.xn(6) = 400;
        m_poly.yn(6) = 100;

    }

    virtual void on_draw()
    {
        typedef agg::renderer_base<agg::pixfmt_bgr24> ren_base;
        typedef agg::renderer_scanline_aa_solid<ren_base> renderer;

        agg::pixfmt_bgr24 pixf(rbuf_window());
        ren_base renb(pixf);
        renderer ren(renb);
        renb.clear(agg::rgba(1, 1, 1));

        agg::rasterizer_scanline_aa<> ras;
        agg::scanline_p8 sl;


        // Form the path. The simplest variant will interpret the curves 
        // as polyline, ingnoring actual "curvature"
        //--------------------------
        agg::path_storage path;
        path.move_to(m_poly.xn(0), m_poly.yn(0));
        path.curve4(m_poly.xn(1), m_poly.yn(1), m_poly.xn(2), m_poly.yn(2), m_poly.xn(3), m_poly.yn(3));
        path.curve4(m_poly.xn(4), m_poly.yn(4), m_poly.xn(5), m_poly.yn(5), m_poly.xn(6), m_poly.yn(6));


/*
        //-----------------------------------------------------------
        // The simplest variant

        // Declare the pipeline
        //--------------------------
        agg::conv_stroke<agg::path_storage> stroke1(path);
        agg::conv_stroke<agg::conv_stroke<agg::path_storage> > stroke2(stroke1);
        //-----------------------------------------------------------
*/



        //-----------------------------------------------------------
        // The variant that interprets the paths as curves and demonstrates that "ass defect"

        // Declare the pipeline
        //--------------------------
        agg::conv_curve<agg::path_storage> curve(path);
        agg::conv_stroke<agg::conv_curve<agg::path_storage> > stroke1(curve);
        agg::conv_stroke<agg::conv_stroke<agg::conv_curve<agg::path_storage> > > stroke2(stroke1);
        //-----------------------------------------------------------


        // Set stroke1 parameters
        //--------------------------
        //stroke1.miter_limit(10.0);
        stroke1.inner_miter_limit(m_inner_lim.value());
        stroke1.line_join(agg::round_join);
        stroke1.line_cap(agg::round_cap);
        stroke1.width(m_width.value());
//        curve.approximation_scale(0.1); // Makes the curve have very few intermediate points

        stroke2.width(1.0);

        // Render stroke1
        //--------------------------
        ren.color(agg::rgba(0.5, 0.3, 0.0, 0.6));
        ras.add_path(stroke1);
        agg::render_scanlines(ras, sl, ren);

        // Render stroke2
        //--------------------------
        ren.color(agg::rgba(0, 0, 0));
        ras.add_path(stroke2);
        agg::render_scanlines(ras, sl, ren);


        // Render the "poly" tool and controls
        //--------------------------
        ras.add_path(m_poly);
        ren.color(agg::rgba(0, 0.3, 0.5, 0.2));
        agg::render_scanlines(ras, sl, ren);


        // Render controls
        //--------------------------
        agg::render_ctrl(ras, sl, ren, m_width);
        agg::render_ctrl(ras, sl, ren, m_inner_lim);
    }


    virtual void on_mouse_button_down(int x, int y, unsigned flags)
    {
        if(flags & agg::mouse_left)
        {
            if(m_poly.on_mouse_button_down(x, y))
            {
                force_redraw();
            }
        }
    }


    virtual void on_mouse_move(int x, int y, unsigned flags)
    {
        if(flags & agg::mouse_left)
        {
            if(m_poly.on_mouse_move(x, y))
            {
                force_redraw();
            }
        }
        if((flags & agg::mouse_left) == 0)
        {
            on_mouse_button_up(x, y, flags);
        }
    }

    virtual void on_mouse_button_up(int x, int y, unsigned flags)
    {
        if(m_poly.on_mouse_button_up(x, y))
        {
            force_redraw();
        }
    }

   
    virtual void on_key(int x, int y, unsigned key, unsigned flags)
    {
    }

};



int agg_main(int argc, char* argv[])
{
    the_application app(agg::pix_format_bgr24, flip_y);
    app.caption("AGG Example. Stroke");

    if(app.init(500, 330, 0))
    {
        return app.run();
    }
    return 1;
}


