The Anti-Grain Geometry Project
A high quality rendering engine for C++
http://antigrain.com

Anti-Grain Geometry
Copyright (C) 2002-2005 Maxim Shemanarev (McSeem) 

Permission to copy, use, modify, sell and distribute this software 
is granted provided this copyright notice appears in all copies. 
This software is provided "as is" without express or implied
warranty, and with no claim as to its suitability for any purpose.

By default only the examples that do not require extra dependancies are built.
with the following commands:

cd (AGGDIRECTORY)/examples/macosx_carbon
make clean
make

Alternatively you can also build the examples one by one, using the example name directly:

make aa_demo
make aa_test
...