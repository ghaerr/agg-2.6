Demonstration the simple method of smoothing polygons with Bezier curves. 
See http://www.antigrain.com/agg_research/bezier_interpolation.html
for more information

Press left mouse button and drag to rotate and scale the image 
around the center point. Press right mouse button and drag 
left-right to change coefficient of smoothing K. Value K=1 
is about 100 pixels from the left border of the window. Each left 
double-click generates a new random polygon. You can also rotate 
and scale it, and chanhe K.

McSeem
www.antigrain.com
